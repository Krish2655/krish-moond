let navbar = document.querySelector('.navbar');

document.querySelector('#menu').onclick = () =>{
    navbar.classList.toggle('active');
}

window.onscroll = () =>{
    navbar.classList.remove('active');
}


$(document).ready(function(){

    $('.button').click(function(){
        $(this).addClass('active').siblings().removeClass('active');

        var filter = $(this).attr('data-filter')

        if(filter == 'all'){
            $('.gallery .image').show(400);
        }
        else{
            $('.gallery .image').not('.' +filter).hide(200);
            $('.gallery .image').filter('.' +filter).show(200);
        }

    });

    $('.gallery').magnificPopup({
        delegate:'a',
        type:'image',
        gallery:{
            enabled:true,
        }
    });

});

 

// modal js

document.addEventListener('DOMContentLoaded', function() {
    var modal = document.getElementById('myModal');
  
    var openModalLink = document.getElementById('openModal');
  
    openModalLink.onclick = function() {
      modal.style.display = 'block'; 
    }
    var span = document.getElementsByClassName('close')[0];
  
     
    span.onclick = function() {
      modal.style.display = 'none';
    }
  
     
    window.onclick = function(event) {
      if (event.target == modal) {
        modal.style.display = 'none';
      }
    }
  
     
    // document.getElementById('login-button').addEventListener('click', function() {
    // //   window.location.href = '/login'; 
    // });
  
    //  document.getElementById('signup-login-form').addEventListener('submit', function(event) {
    //    event.preventDefault();
       
      // alert('Sign up logic goes here');
    // });
  });

  // button modal
  
  var openModalButton = document.getElementById("openModalButton");
  var modal = document.getElementById("myModal");
  
  // When the user clicks the button, show the modal
  openModalButton.onclick = function() {
      modal.style.display = "block";
  };
  
  // When the user clicks on the close button or anywhere outside of the modal, close it
  var closeModal = document.getElementsByClassName("close")[0];
  window.onclick = function(event) {
      if (event.target == modal || event.target == closeModal) {
          modal.style.display = "none";
      }
  };

  //modal 2
  var openModalButton = document.getElementById("openModalButton1");
  var modal = document.getElementById("myModal");
  
  // When the user clicks the button, show the modal
  openModalButton.onclick = function() {
      modal.style.display = "block";
  };
  
  // When the user clicks on the close button or anywhere outside of the modal, close it
  var closeModal = document.getElementsByClassName("close")[0];
  window.onclick = function(event) {
      if (event.target == modal || event.target == closeModal) {
          modal.style.display = "none";
      }
  };

  //modal 3

  var openModalButton = document.getElementById("openModalButton2");
  var modal = document.getElementById("myModal");
  
  // When the user clicks the button, show the modal
  openModalButton.onclick = function() {
      modal.style.display = "block";
  };
  
  // When the user clicks on the close button or anywhere outside of the modal, close it
  var closeModal = document.getElementsByClassName("close")[0];
  window.onclick = function(event) {
      if (event.target == modal || event.target == closeModal) {
          modal.style.display = "none";
      }
  };

  //modal 4

  var openModalButton = document.getElementById("openModalButton3");
  var modal = document.getElementById("myModal");
  
  // When the user clicks the button, show the modal
  openModalButton.onclick = function() {
      modal.style.display = "block";
  };
  
  // When the user clicks on the close button or anywhere outside of the modal, close it
  var closeModal = document.getElementsByClassName("close")[0];
  window.onclick = function(event) {
      if (event.target == modal || event.target == closeModal) {
          modal.style.display = "none";
      }
  };

  //modal 5

  var openModalButton = document.getElementById("openModalButton4");
  var modal = document.getElementById("myModal");
  
  // When the user clicks the button, show the modal
  openModalButton.onclick = function() {
      modal.style.display = "block";
  };
  
  // When the user clicks on the close button or anywhere outside of the modal, close it
  var closeModal = document.getElementsByClassName("close")[0];
  window.onclick = function(event) {
      if (event.target == modal || event.target == closeModal) {
          modal.style.display = "none";
      }
  };

  //modal 6
  var openModalButton = document.getElementById("openModalButton5");
  var modal = document.getElementById("myModal");
  
  // When the user clicks the button, show the modal
  openModalButton.onclick = function() {
      modal.style.display = "block";
  };
  
  // When the user clicks on the close button or anywhere outside of the modal, close it
  var closeModal = document.getElementsByClassName("close")[0];
  window.onclick = function(event) {
      if (event.target == modal || event.target == closeModal) {
          modal.style.display = "none";
      }
  };

  //modal 7

  var openModalButton = document.getElementById("openModalButton6");
  var modal = document.getElementById("myModal");
  
  // When the user clicks the button, show the modal
  openModalButton.onclick = function() {
      modal.style.display = "block";
  };
  
  // When the user clicks on the close button or anywhere outside of the modal, close it
  var closeModal = document.getElementsByClassName("close")[0];
  window.onclick = function(event) {
      if (event.target == modal || event.target == closeModal) {
          modal.style.display = "none";
      }
  };


  //modal 8

  var openModalButton = document.getElementById("openModalButton7");
  var modal = document.getElementById("myModal");
  
  // When the user clicks the button, show the modal
  openModalButton.onclick = function() {
      modal.style.display = "block";
  };
  
  // When the user clicks on the close button or anywhere outside of the modal, close it
  var closeModal = document.getElementsByClassName("close")[0];
  window.onclick = function(event) {
      if (event.target == modal || event.target == closeModal) {
          modal.style.display = "none";
      }
  };