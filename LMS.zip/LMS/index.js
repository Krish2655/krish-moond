const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

mongoose.connect("mongodb+srv://Krish:Krish2655@cluster0.wkhqdfx.mongodb.net/ecommerce", {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
  .then(() => console.log('MongoDB Connected'))
  .catch(err => console.error(err));

const userSchema = new mongoose.Schema({
// username:String,
// email:String,
// password:String
name:String,
email:String,
contact:Number,
subject:String,
msg:String,

});

const User = mongoose.model('User', userSchema);

var path1= require('path');
var path=path1.join(__dirname,'../LMS')
app.use(express.static(path));
app.use('/regis',express.static(path),function(req,res,next){
    res.sendFile(path+'/index.html');
});

app.post('/register', async (req, res) => {
    try {
      // const { username, email, password } = req.body; 
      const { name, email,contact,subject,msg } = req.body; 
      // const newUser = new User({ username, email, password }); 
      const newUser = new User({ name, email,contact,subject,msg }); 
      await newUser.save(); 
      // res.status(201).send('User registered successfully!');
      // res.send('<script>alert("Message sent successfully!");</script>');
      // res.redirect('/home');

      const alertHTML = `
      <!DOCTYPE html>
      <html lang="en">
      <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Alert Box</title>
      <style>
      .alert-container {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background-color: #f8d7da;
        color: #721c24;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      }
      
      .alert-container h2 {
        margin-top: 0;
      }
      
      .alert-button {
        display: block;
        margin-top: 20px;
        text-align: center;
      }
      
      .alert-button button {
        padding: 10px 20px;
        background-color: #dc3545;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
      }
      
      .alert-button button:hover {
        background-color: #c82333;
      }
      </style>
      </head>
      <body>
      <div class="alert-container">
        <h2>Message sent successfully!</h2>
        <div class="alert-button">
          <button onclick="redirectToHome()">Go to Home</button>
        </div>
      </div>
      <script>
      function redirectToHome() {
        window.location.href = '/index.html';  
      }
      </script>
      </body>
      </html>
    `;
    res.send(alertHTML);
      
    } catch (error) {
      console.error('Error registering user:', error); 
      res.status(500).send('Failed to register user');
    }
  });
  

//modal mongo
  const userSchema1 = new mongoose.Schema({
   username:String,
   pass:String
    
    });
const User1 = mongoose.model('user1', userSchema1);

app.post('/login', async (req, res) => {
  try {
    // const { username, email, password } = req.body; 
    const { username,pass } = req.body; 
    
    // const newUser = new User({ username, email, password }); 
    const newUser1 = new User1({ username,pass}); 
    await newUser1.save(); 
    // res.status(201).send('User registered successfully!');
    // res.send('<script>alert("Message sent successfully!");</script>');
    // res.redirect('/home');

     
  // res.send(alertHTML);
  // res.sendFile(path.join(viewsPath+"/after.html"));
  res.sendFile(__dirname+'/'+'after.html')
    
  } catch (error) {
    console.error('Error registering user:', error); 
    res.status(500).send('Failed to register user');
  }
});



const PORT = 2500;
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
